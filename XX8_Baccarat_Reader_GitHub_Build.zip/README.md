# XX8 Baccarat Reader — Android starter project

This is an experimental Android Studio starter project for a floating overlay and on-device OCR.

## What it does
- Requests Android screen sharing (MediaProjection).
- Shows a small floating overlay above other apps.
- Uses on-device ML Kit text recognition on the lower part of the screen.
- Speaks a detected B/P/T letter in Vietnamese after repeated matching frames.

## Important limitations
- This is **not a finished or validated XX8 integration** and no APK is included.
- The OCR heuristic is deliberately basic. The XX8 bead-road circles can be missed or confused with labels elsewhere in the cropped area. It must be tested against the exact live layout and improved with a fixed region-of-interest / color-and-shape classifier before relying on it.
- It only reports visible outcomes; it does not predict future hands or guarantee betting results.
- Android may stop screen capture when the user leaves the app, locks the phone, or revokes screen-sharing permission.
- Screen contents are processed locally by ML Kit; this starter code does not upload screenshots.

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Allow Gradle sync and install the app on an Android device.
3. Tap **Cấp quyền cửa sổ nổi** and allow display over other apps.
4. Tap **Bắt đầu chia sẻ màn hình**, then approve Android's screen-capture prompt.
5. Open XX8. Long-press the floating bubble to stop the service.

## Before real use
Test with non-betting/demo content first. Verify every spoken result against the table. The sample currently extracts the last OCR-recognized B/P/T character, so false readings are possible.
