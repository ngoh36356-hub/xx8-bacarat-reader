# Tạo APK chỉ bằng điện thoại Android qua GitHub Actions

Bạn cần một tài khoản GitHub. Không cần cài Android Studio trên điện thoại.

## A. Tải và giải nén
1. Tải file ZIP dự án này về điện thoại.
2. Mở ứng dụng Files / Tệp của bạn và giải nén ZIP.
3. Vào https://github.com và đăng nhập hoặc tạo tài khoản.

## B. Tạo repository
1. Trên GitHub, nhấn dấu `+` → `New repository`.
2. Đặt tên `xx8-baccarat-reader`, chọn `Public` hoặc `Private`, rồi tạo repository.
3. Trong repository, chọn `Add file` → `Upload files`.
4. Mở thư mục dự án đã giải nén, chọn và tải lên toàn bộ nội dung bên trong (bao gồm thư mục `.github`).
   - Nếu điện thoại không hiện thư mục `.github`, bật hiển thị tệp ẩn trong ứng dụng quản lý tệp.
5. Nhấn `Commit changes`.

## C. Chạy biên dịch
1. Mở tab `Actions` trong repository.
2. Chọn workflow `Build Android APK`.
3. Nhấn `Run workflow` → `Run workflow`.
4. Chờ job có dấu tích xanh.
5. Mở lần chạy vừa hoàn tất, kéo xuống `Artifacts`.
6. Tải `XX8-Baccarat-Reader-debug` về điện thoại và giải nén.
7. Chạm `app-debug.apk` để cài. Nếu Android hỏi, cho phép cài ứng dụng từ nguồn này.

## Lưu ý quan trọng
- Đây là APK debug thử nghiệm, chưa được kiểm chứng trên XX8 thực tế.
- Nhận diện OCR hiện là heuristic đơn giản; có thể đọc nhầm chữ B/P/T trong bảng lịch sử. Hãy thử ở chế độ không đặt cược và đối chiếu từng kết quả.
- Ứng dụng chỉ đọc kết quả đang hiển thị, không dự đoán kết quả tiếp theo và không đảm bảo thắng cược.
- Nếu GitHub báo lỗi build, chụp màn hình phần log lỗi gửi lại để được sửa.
