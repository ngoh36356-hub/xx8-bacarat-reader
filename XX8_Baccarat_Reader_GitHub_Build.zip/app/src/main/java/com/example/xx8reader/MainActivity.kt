package com.example.xx8reader

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private val captureRequest = 701
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 48, 32, 32)
            setBackgroundColor(Color.rgb(247, 248, 250))
        }
        layout.addView(TextView(this).apply {
            text = "XX8 BACCARAT READER"
            textSize = 24f
            setTextColor(Color.rgb(20, 70, 45))
        })
        layout.addView(TextView(this).apply {
            text = "Cửa sổ nổi nhận diện thử nghiệm P / B / T từ vùng lịch sử ở cuối màn hình. Cần cấp quyền hiển thị trên ứng dụng khác và chia sẻ màn hình."
            textSize = 16f
            setPadding(0, 24, 0, 24)
        })
        layout.addView(Button(this).apply {
            text = "1. Cấp quyền cửa sổ nổi"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    requestCapture()
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "2. Bắt đầu chia sẻ màn hình"
            setOnClickListener { requestCapture() }
        })
        layout.addView(Button(this).apply {
            text = "Dừng hướng dẫn / đóng ứng dụng"
            setOnClickListener { stopService(Intent(this, ReaderService::class.java)) }
        })
        setContentView(layout)
    }

    private fun requestCapture() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            return
        }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
    }

    @Deprecated("Deprecated by Android, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, ReaderService::class.java).apply {
                putExtra("resultCode", resultCode)
                putExtra("projectionData", data)
            }
            startForegroundService(service)
            finish()
        }
    }
}
