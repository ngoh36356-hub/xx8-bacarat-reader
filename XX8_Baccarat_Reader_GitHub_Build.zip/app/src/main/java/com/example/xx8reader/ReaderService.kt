package com.example.xx8reader

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

class ReaderService : Service(), TextToSpeech.OnInitListener {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null
    private var overlay: TextView? = null
    private var tts: TextToSpeech? = null
    private var lastSpoken = ""
    private var lastCandidate = ""
    private var stableCount = 0
    private val busy = AtomicBoolean(false)
    private lateinit var worker: Handler
    private lateinit var thread: HandlerThread
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this, this)
        thread = HandlerThread("xx8-ocr").also { it.start() }
        worker = Handler(thread.looper)
        createNotification()
        showOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra("projectionData", Intent::class.java)
        else @Suppress("DEPRECATION") intent?.getParcelableExtra("projectionData")
        if (code == Activity.RESULT_OK && data != null) startProjection(code, data)
        return START_NOT_STICKY
    }

    private fun createNotification() {
        val channelId = "xx8_reader"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(channelId, "XX8 Reader",
                NotificationManager.IMPORTANCE_LOW))
        }
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId).setContentTitle("XX8 Baccarat Reader")
                .setContentText("Đang nhận diện màn hình — chạm Dừng trên cửa sổ nổi để kết thúc")
                .setSmallIcon(android.R.drawable.ic_menu_view).build()
        else Notification.Builder(this).setContentTitle("XX8 Baccarat Reader")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(9, notification)
    }

    private fun showOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val bubble = TextView(this).apply {
            text = "XX8\nĐANG ĐỌC"
            textSize = 12f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(18, 14, 18, 14)
            setBackgroundColor(0xDD14532D.toInt())
            setOnClickListener {
                text = "XX8\nĐỌC: $lastSpoken"
            }
            setOnLongClickListener {
                stopSelf()
                true
            }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 18; y = 180
        }
        try { wm.addView(bubble, params); overlay = bubble } catch (_: Exception) {}
    }

    private fun startProjection(code: Int, data: Intent) {
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        display = projection?.createVirtualDisplay("XX8Reader", width, height,
            metrics.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, worker)
        reader?.setOnImageAvailableListener({ source ->
            val image = source.acquireLatestImage() ?: return@setOnImageAvailableListener
            if (busy.compareAndSet(false, true)) processImage(image) else image.close()
        }, worker)
    }

    private fun processImage(image: Image) {
        try {
            val bitmap = image.toBottomBitmap()
            image.close()
            val input = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(input)
                .addOnSuccessListener { result ->
                    // Restrict OCR interpretation to the lower road/history area.
                    val letters = result.text.uppercase().filter { it == 'B' || it == 'P' || it == 'T' }
                    val candidate = letters.lastOrNull()?.toString() ?: ""
                    if (candidate.isNotEmpty() && candidate == lastCandidate) stableCount++ else {
                        lastCandidate = candidate; stableCount = if (candidate.isEmpty()) 0 else 1
                    }
                    // Require repeated identical readings and ignore already announced outcomes.
                    if (stableCount >= 3 && candidate != lastSpoken) {
                        lastSpoken = candidate
                        overlay?.post { overlay?.text = "XX8\nKẾT QUẢ: $candidate\nGiữ để dừng" }
                        val spoken = when(candidate) { "B" -> "Nhà cái"; "P" -> "Tay con"; else -> "Hòa" }
                        tts?.speak(spoken, TextToSpeech.QUEUE_FLUSH, null, "xx8-$candidate")
                    }
                }
                .addOnCompleteListener { busy.set(false); bitmap.recycle() }
        } catch (_: Exception) {
            try { image.close() } catch (_: Exception) {}
            busy.set(false)
        }
    }

    private fun Image.toBottomBitmap(): android.graphics.Bitmap {
        val plane = planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * width
        val full = android.graphics.Bitmap.createBitmap(
            width + rowPadding / pixelStride, height, android.graphics.Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(plane.buffer)
        val cropTop = (height * 0.66f).toInt()
        return android.graphics.Bitmap.createBitmap(full, 0, cropTop, width, height - cropTop).also {
            full.recycle()
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("vi", "VN")
    }

    override fun onDestroy() {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            overlay?.let { wm.removeView(it) }
        } catch (_: Exception) {}
        display?.release()
        reader?.close()
        projection?.stop()
        recognizer.close()
        tts?.stop(); tts?.shutdown()
        thread.quitSafely()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
